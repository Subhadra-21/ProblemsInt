import React from 'react';
import Routes from "./components/Routes";
import ActionContainer from './components/ActionContainer';
import "./App.css";

const App = () => {
  return (
    <main className='main'>
      <ActionContainer />
      <Routes />
    </main>
  )
}

export default App