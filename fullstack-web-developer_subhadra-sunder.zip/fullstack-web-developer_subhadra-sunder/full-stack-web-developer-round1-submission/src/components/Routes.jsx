
import {useRoutes} from 'react-router-dom';
import { Home, JoinTable, Filter } from './pages';
const Routes = () => {
  const routeElems = useRoutes([
    {path: '/', element:<Home />},
    {path: '/join', element: <JoinTable />},
    {path: '/filter', element: <Filter/>}
  ]);  
  return routeElems;
}

export default Routes