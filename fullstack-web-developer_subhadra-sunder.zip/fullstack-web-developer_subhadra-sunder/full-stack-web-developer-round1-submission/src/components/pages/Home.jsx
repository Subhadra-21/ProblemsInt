import React from 'react'
import "./page.css";
const Home = () => {
  return (
    <section className="pageSection">
        <div className="welcomeTxt">Welcome to CRM</div>
    </section>
  )
}

export default Home