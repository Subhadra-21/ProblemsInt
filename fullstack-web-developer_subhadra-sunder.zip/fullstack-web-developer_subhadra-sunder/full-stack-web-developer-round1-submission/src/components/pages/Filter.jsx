import React from 'react'
import "./page.css";
const Filter = () => {
  return (
    <section className="pageSection">
        Filter
    </section>
  )
}

export default Filter