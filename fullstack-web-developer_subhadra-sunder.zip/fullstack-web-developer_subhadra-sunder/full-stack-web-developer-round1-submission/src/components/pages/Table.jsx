import Table from "react-bootstrap/Table";

const TableComp = ({ data = [] }) => {
  console.log(data);
  return (
    <Table striped bordered hover responsive className="p-table" cellSpacing="0"
    width="100%">
      <thead>
        <tr>
          <th>ProductName</th>
          <th>Product Description</th>
        </tr>
      </thead>

      <tbody>
        {data.map((r) => {
          return (
            <tr>
              <td>{r.ProductName}</td>
              <td>{r.ProductDescription}</td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );
};

export default TableComp;
