export const tableList = [
    {
        label: 'accounts',
        tname: 'accounts',
        fileds: ['ProductKey'],
        selField: '',
        idx:0,
    },
    {
        label: 'clicks',
        tname: 'clicks',
        fileds: ['ProductKey'],
        selField: '',
        idx:1,
    },
    {
        label: 'products',
        tname: 'products',
        fileds: ['ProductKey','ProductName', 'ModelName'],
        selField: '',
        idx:2,
    },
    {
        label: 'sales_pipeline',
        tname: 'sales',
        fileds: ['ProductKey'],
        selField: '',
        idx:3,
    },
    {
        label: 'sales_teams',
        tname: 'sales',
        fileds: ['ProductKey', 'OrderDate'],
        selField: '',
        idx:4,
    }
];