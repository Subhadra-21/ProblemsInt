import React, { useState } from 'react'
import "./page.css";
import "./JoinTable.css";
import { tableList } from './constants';
import table_black from "../../assets/table_black.png";
import table_blue from "../../assets/table_blue.png";
import TableComp from './Table';

import axios from 'axios';

const JoinTable = () => {
  const [tabLists, setTableList] = useState(tableList);

  const [tableData, setTableData] = useState(null);

  const handleSelct = (idx) => {
    const newTabList = [...tabLists.slice(0,idx), {...tabLists[idx], sel:!tabLists[idx].sel},...tabLists.slice(idx+1) ]
    if(newTabList.filter(f => f.sel).length>2) {
        alert('only 2 can be selected');
        return false;
    }
    setTableList(newTabList); 
  }

  const setFieldSel = (idx, fval) => {
    const newTabList = [...tabLists.slice(0,idx), {...tabLists[idx], selField:fval},...tabLists.slice(idx+1) ]
    setTableList(newTabList); 
  }

  const handleJoinClick = async () => {
    const selFields = tabLists.filter(f => {
        return f.selField && f.sel
      });
    const tname1 = selFields[0].tname;
    const tname2 = selFields[1].tname;
    const fieldName =  selFields[0].selField;
    try{
        const data = await axios.get('http://localhost:4000/join-tables', {
            params: {
                table_name1:tname1,
                table_name2:tname2,
                join_field:fieldName
            }
        });
        console.log(data);
        setTableData(data.data);
    }
    catch(err){
        console.log(err)
    }
    
  }

  const selFields = tabLists.filter(f => {
    return f.selField && f.sel
  }).length===2;

  return (
    <section className="pageSection">
        <div className='joinContainer'>
            <div className="tableSelector">
                {
                    tabLists.map((tab, idx) => {
                        return (
                            <div draggable onClick={()=>{handleSelct(idx)}} className={`tableIcon ${tab.sel ? 'selected' : ''}`}>
                                <img width="150" src={tab.sel ? table_blue : table_black} alt="Table icon"/>
                                <p>{tab.label}</p>
                            </div>
                        )
                    })
                }
            </div>
            <div>
                
            </div>
            <div className="tableViewer">
                <div className="tableViewer-div">
                {
                    tabLists.filter(f=>f.sel).map((tab,tidx) => {
                        return (
                            <div className={`tableIcon`}>
                                <img width="150" src={table_blue} alt="Table icon"/>
                                <p>{tab.label}</p>
                                <div className="filedList">
                                    {
                                        tab.fileds.map((f) => {
                                           return <p onClick={()=>{setFieldSel(tab.idx, f)}} className={`filed`}>{f}</p>
                                        })
                                    }
                                </div>
                            </div>
                        )
                    })
                }
                </div>
                 {selFields && <button onClick={handleJoinClick}>JOIN</button>}
                 {tableData && <TableComp data={tableData.data} />}
            </div>
           
        </div>
    </section>
  )
}

export default JoinTable