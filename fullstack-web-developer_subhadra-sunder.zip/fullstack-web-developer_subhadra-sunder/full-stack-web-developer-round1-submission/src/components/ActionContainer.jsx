import React from "react";
import { Link, useLocation } from "react-router-dom";
import "./ActionContainer.css";

const ActionContainer = () => {
  const location = useLocation();
  const isActiveRoute = (path) => {
    return location.pathname === path;
  };
  return (
    <section className="action-container">
      <div className="action-item">
        <Link to="/join" className={`act-btn ${isActiveRoute("/join") ? "active" : ""}`}>JOIN</Link>
      </div>
      <div className="action-item">
          <Link to="/filter" className={`act-btn ${isActiveRoute("/filter") ? "active" : ""}`}>FILTER</Link>
      </div>
    </section>
  );
};

export default ActionContainer;
