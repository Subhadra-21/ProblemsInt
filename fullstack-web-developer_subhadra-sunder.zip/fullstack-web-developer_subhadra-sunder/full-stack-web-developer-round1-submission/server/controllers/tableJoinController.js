const { createReadStream } = require("fs");
const csv = require("csv-parser");
const path = require("path");

async function readCsv(filePath){
    const fileStream = createReadStream(filePath);
    const rowData = [];

    return new Promise((resolve, reject)=>{
        fileStream.pipe(csv())
        .on('data', (row)=>{ rowData.push(row)})
        .on('end', ()=>{resolve(rowData)})
        .on('error',()=>{reject()});
    });
}

async function tableJoinController(req, res){
    const {table_name1, table_name2, join_field } = req.query;
    if(!table_name1 || !table_name2 || !join_field){
        return res.status(400).json({error:'data missing'});
    }
    if(table_name1 !== 'products' || table_name2 !== 'sales'){
        return res.status(400).json({error:'these tables not supported currently'});
    }
    try{
        const file1Data = await readCsv(path.resolve(__dirname,`../db/${table_name1}.csv`));
        const file2Data = await readCsv(path.resolve(__dirname,`../db/${table_name2}.csv`));
        const joinedData = file1Data.reduce((prev,row1) => {
            const matchingRow = file2Data.find((row2) => row2[join_field] === row1[join_field]);
            prev.push({ ...row1, ...matchingRow });
            return prev;
        },[]);
        res.json({data:joinedData});
    }catch(err){
        return res.status(400).json({error:'something went wrong'});
    }
    
}

module.exports = tableJoinController;