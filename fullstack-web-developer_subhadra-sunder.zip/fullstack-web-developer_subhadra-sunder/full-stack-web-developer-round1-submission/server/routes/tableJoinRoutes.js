const express = require("express");
const router = express.Router();
const tableJoinController = require("../controllers/tableJoinController");

router.get('/join-tables', tableJoinController);

module.exports = router;