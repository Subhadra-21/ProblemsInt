const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const joinRoutes = require("./routes/tableJoinRoutes");

const app = express();

app.use(bodyParser.json());
app.use(cors())

app.use("/", joinRoutes);

app.listen(4000, ()=>{
    console.log('server running at 4000');
});